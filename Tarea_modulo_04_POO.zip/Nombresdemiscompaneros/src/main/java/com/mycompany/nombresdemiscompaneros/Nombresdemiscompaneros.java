package com.mycompany.nombresdemiscompaneros;
public class Nombresdemiscompaneros {
public static void main(String[] args) {
String[] nombres = {
"ARNOLD ELIGIO AGUILAR CONTRERAS",
"LISNY ALEXANDRA AGUILAR PAREDES",
"KEYSI YOELY AGUIRRE FUENTES",
"ARNOL RAFAEL GUTIERREZ ALFARO",
"BRIPNY LIZETH DUARTE GOMEZ",
"CARLOS ROBERTO QUINTERO CHICAS",
"CRISTIAN FERNANDO ZAMORA ENAMORADO",
"DANLIS LEONEL BAIDE ENAMORADO",
"DIMAS BELSASAR HERNANDEZ HERRERA",
"EMANUEL ALEXANDER ORELLANA MARTINEZ"
};

System.out.println("Nombres de mis companeros de clases de POO:");
System.out.println("");
for (String nombre : nombres) {
System.out.println(nombre);
}
}
}


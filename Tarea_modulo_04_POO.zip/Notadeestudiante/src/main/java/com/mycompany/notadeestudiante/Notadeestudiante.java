package com.mycompany.notadeestudiante;
import java.util.Scanner;

public class Notadeestudiante {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

System.out.print("Ingrese el nombre: ");
String nombre = scanner.nextLine();

System.out.print("Ingrese la nota: ");
int nota = scanner.nextInt();

String resultado;
if (nota >= 70) {
resultado = "Aprobado";
} else {
resultado = "Reprobado";
}

System.out.println("\nNombre: " + nombre);
System.out.println("Nota: " + nota);
System.out.println(resultado);

scanner.close();
}
}

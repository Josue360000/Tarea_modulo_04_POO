package com.mycompany.datosdecompanerosdeclases;
public class Datosdecompanerosdeclases {
public static void main(String[] args) {
String[][] datcompa = {
{"Carlos Fernando", "Portillo Sierra", "Ing en Sistemas", "Tecnicom"},
{"Arnold Eligio", "Aguilar Contreras", "Ing Electronica", "Energia Renovable"},
{"Diana Alejandra", "Selva Perdomo", "Ing en Sistemas", "Construccion"},
{"Mirna Yonali", "Garcia Chirino", "Ing Industrial", "Control de Calidad"},
{"Ruth Elizabeth", "Bautista Quintanilla", "Ing Industrial", "Corporacion LEAR"},
};

System.out.println("Datos de companeros de clases:");
System.out.println("");
for (int i = 0; i < datcompa.length; i++) {
System.out.println("Nombres: " + datcompa[i][0]);
System.out.println("Apellidos: " + datcompa[i][1]);
System.out.println("Carrera: " + datcompa[i][2]);
System.out.println("Lugar de trabajo: " + datcompa[i][3]);
System.out.println();
}
}
}

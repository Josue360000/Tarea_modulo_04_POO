package com.mycompany.evaluaciondeexpresiones;
public class Evaluaciondeexpresiones {
    public static void main(String[] args) {
        int M = 6;
        int T = 1;
        int K = -10;

        if (M > T) {
            System.out.println("M > T: verdadero");
        } else {
            System.out.println("M > T: falso");
        }

        if (T / K == -5) {
            System.out.println("T / K == -5: verdadero");
        } else {
            System.out.println("T / K == -5: falso");
        }

        if ((M + T == 7) || (M - T == 5)) {
            System.out.println("(M + T == 7) || (M - T == 5): verdadero");
        } else {
            System.out.println("(M + T == 7) || (M - T == 5): falso");
        }
    }
}

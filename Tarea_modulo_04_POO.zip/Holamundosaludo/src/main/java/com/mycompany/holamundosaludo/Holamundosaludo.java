package com.mycompany.holamundosaludo;
class Holamundosaludo {
    public static void main(String[] args) {
        System.out.println("Hola, soy Hector Nunez");
    }
}